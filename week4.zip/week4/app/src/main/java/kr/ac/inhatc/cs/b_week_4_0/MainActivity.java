package kr.ac.inhatc.cs.b_week_4_0;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.databinding.DataBindingUtil;

import kr.ac.inhatc.cs.b_week_4_0.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_main);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // AppBar 나타내기 - ToolBar 사용
        setSupportActionBar(binding.materialToolbar);
        getSupportActionBar().setTitle("4(?)주차");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        binding.btnAnalogDigitalClock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AnalogDigitalClockActivity.class);
                startActivity(intent);
            }
        });

        binding.btnChrono.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ChronometerActivity.class);
            startActivity(intent);
        });

        binding.btnTimePicker.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TimePickerActivity.class);
            startActivity(intent);
        });

        binding.btnDatePicker.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DatePickerActivity.class);
            startActivity(intent);
        });

        binding.btnAutoCompleteTextView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AutoCompleteTextViewActivity.class);
            Log.i("Check", "AutoComplete 액티비티 호출");
            startActivity(intent);
        });

        binding.btnProgressSeekRating.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProgressSeekRatingActivity.class);
            startActivity(intent);
        });
    }
}