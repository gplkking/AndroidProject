package kr.ac.inhatc.cs.b_week_4_0;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.DatePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.databinding.DataBindingUtil;

import kr.ac.inhatc.cs.b_week_4_0.databinding.ActivityDatePickerBinding;

public class DatePickerActivity extends AppCompatActivity {

    private ActivityDatePickerBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_date_picker);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_date_picker);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setSupportActionBar(binding.materialToolbar5);
        getSupportActionBar().setTitle("DatePicker");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        binding.btnDatePickerSpinner.setOnClickListener(v -> {
            Log.i("Check", "1. 선택한 연도는 : " + binding.datePickerSpinner.getYear() );  //
            Log.i("Check", "2. 선택한 월은   : " + (binding.datePickerSpinner.getMonth() + 1)); // Month는 0 ~ 11 때문에
            Log.i("Check", "3. 선택한 일은   : " + binding.datePickerSpinner.getDayOfMonth());
        });

        binding.btnHideCalendar.setOnClickListener(v -> {

            // API23, Android 7.0부터 deprecated
            if(binding.datePickerSpinner.getCalendarViewShown()) {
                binding.datePickerSpinner.setCalendarViewShown(false);
            } else {
                binding.datePickerSpinner.setCalendarViewShown(true);
            };
        });

        binding.btnDatePickerCalendar.setOnClickListener(v -> {
            Log.i("Check", "1. 선택한 연도는 : " + binding.datePickerCalendar.getYear() );  //
            Log.i("Check", "2. 선택한 월은   : " + (binding.datePickerCalendar.getMonth() + 1)); // Month는 0 ~ 11 때문에
            Log.i("Check", "3. 선택한 일은   : " + binding.datePickerCalendar.getDayOfMonth());
        });

        binding.btnFinish.setOnClickListener(v -> {
            finish();
        });
    }
}