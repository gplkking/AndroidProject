package kr.ac.inhatc.cs.b_week_4_0;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.databinding.DataBindingUtil;

import kr.ac.inhatc.cs.b_week_4_0.databinding.ActivityTimePickerBinding;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TimePickerActivity extends AppCompatActivity {

    private ActivityTimePickerBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_time_picker);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_time_picker);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setSupportActionBar(binding.materialToolbar4);
        getSupportActionBar().setTitle("TimePicker");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        binding.btnTimePickerClock.setOnClickListener(v -> {
            Log.i("Check", binding.timePickerClock.getHour() + ":" + binding.timePickerClock.getMinute());
        });

        binding.btnTimePickerSpinner.setOnClickListener(v -> {
            // timePickerSpinner의 결과 확인
            Log.i("Check", binding.timePickerSpinner.getHour() + ":" + binding.timePickerSpinner.getMinute());

            // editText, inputType="time"일 때 결과 확인
            String timeText = binding.editTextTime.getText().toString();
            Log.i("Check", "1. 확인된 시간은: " + timeText);

            try {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
                // hh:mm은 24시간 제
                // HH:mm은 12시간 제
                Date date = sdf.parse(timeText);
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date);

                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                int second = calendar.get(Calendar.SECOND);
                Log.i("Check", "2. Inputed Time: " + hour + ":" + minute + ":" + second);
            } catch (ParseException e) {
                //throw new RuntimeException(e);
                //e.printStackTrace();
                Log.i("Check", "Exception 발생");
            }

        });

        // TimePicker를 클릭할 때 이벤트핸들러를 연결하는 방법
        /*binding.editTextTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog(v);
            }
        });*/

        /*binding.editTextTime.setOnClickListener(v -> {
            showTimePickerDialog(v);
        });*/

        binding.editTextTime.setOnClickListener(this::showTimePickerDialog);
        binding.btnFinish.setOnClickListener(v -> {
            finish();
        });
    }

    private void showTimePickerDialog(View v) {
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        new TimePickerDialog(v.getContext(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute ) {
                // 12시간 형식은 0~11 범위의 시간과 오전/오후 포함하는 문자열로
                // 24시간 형식은 0~23 범위의 시간으로...
                Calendar selectedTime = Calendar.getInstance();
                selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selectedTime.set(Calendar.MINUTE, minute);
                selectedTime.set(Calendar.SECOND, 0);

                //@SuppressLint("DefaultLocale") String time = String.format("%02d:%02d", hourOfDay, minute);
                //((EditText) v).setText(time);
                // "hh:mm:ss a" 형식으로 EditText에 설정  - 예) 04:30:00 PM
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
                String time = sdf.format(selectedTime.getTime());
                ((EditText) v).setText(time);
            }
        }, hour, minute, false).show(); // 마지막 매개변수: true이면 24시간제, false이면 12시간제
                                                  // true이면 다이얼로그에 표시되는 시계가 24시간 형식
                                                  // false이면 다이얼로그에 표시되는 시계가 12시간 형식
    }
}