package kr.ac.inhatc.cs.b_week_4_0;

import android.os.Bundle;
import android.os.SystemClock;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.databinding.DataBindingUtil;

import kr.ac.inhatc.cs.b_week_4_0.databinding.ActivityChronometerBinding;

public class ChronometerActivity extends AppCompatActivity {

    private ActivityChronometerBinding binding;
    private long pausedTime = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_chronometer);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_chronometer);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.chrono), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setSupportActionBar(binding.materialToolbar3);
        getSupportActionBar().setTitle("Chronometer - Timer");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        binding.btnStart.setEnabled(true);
        binding.btnStop.setEnabled(false);
        binding.btnReset.setEnabled(true);

        binding.btnStart.setOnClickListener(v -> {
            // 크로노미터가 시작하는 시간을 설정한다. 0으로 시작
            // 설정하지 않으면 앱이 시작된 시간 : 크로노미터가 나타난 시간 부터
            binding.chronometer.setBase(SystemClock.elapsedRealtime() + pausedTime);
            binding.chronometer.start();
            binding.btnStart.setEnabled(false);
            binding.btnStop.setEnabled(true);
            binding.btnReset.setEnabled(false);
        });

        binding.btnStop.setOnClickListener(v -> {
            pausedTime = binding.chronometer.getBase() - SystemClock.elapsedRealtime();
            binding.chronometer.stop();
            binding.btnStart.setEnabled(true);
            binding.btnStop.setEnabled(false);
            binding.btnReset.setEnabled(true);
        });

        binding.btnReset.setOnClickListener(v -> {
            pausedTime = 0L;
            binding.chronometer.setBase(SystemClock.elapsedRealtime());
            binding.chronometer.stop();
            binding.btnStart.setEnabled(true);
            binding.btnStop.setEnabled(false);
            binding.btnReset.setEnabled(true);
        });

        binding.btnBackToHome.setOnClickListener(v -> {
            finish();
        });
    }
}