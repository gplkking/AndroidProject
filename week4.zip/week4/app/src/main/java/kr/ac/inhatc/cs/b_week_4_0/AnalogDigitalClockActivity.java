package kr.ac.inhatc.cs.b_week_4_0;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.databinding.DataBindingUtil;

import kr.ac.inhatc.cs.b_week_4_0.databinding.ActivityAnalogDigitalClockBinding;

import java.util.Calendar;
import java.util.TimeZone;

public class AnalogDigitalClockActivity extends AppCompatActivity {

    private ActivityAnalogDigitalClockBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_analog_digital_clock);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_analog_digital_clock);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.analogDigitalClock), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setSupportActionBar(binding.materialToolbar2);
        getSupportActionBar().setTitle("Analog & Digital Clock");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        // 시스템 타임존 설정 - 권장하지 않는 방법 :
        //      앱의 타임존은 변경되지만 시스템의 타임존은 변경되지 않는다.
        //      앱의 타임 존을 설정하면 AlalogClock에는 적용되지만, DigitalClock에는 적용되지 않는 문제...
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Seoul"));

        binding.textClock.setTimeZone("Asia/Seoul"); // TextClock은 직접 타임존 설정
        // AnalogClock과 DigitalClock 컴포넌트는 TimeZone 설정 기능이 없다.
        // 시스템의 TimeZone을 따르게 된다.

        binding.btnBackToHome.setOnClickListener(v -> {
            finish();
        });
    }
}