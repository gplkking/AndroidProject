package kr.ac.inhatc.cs.b_week_4_0;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.databinding.DataBindingUtil;

import kr.ac.inhatc.cs.b_week_4_0.databinding.ActivityProgressSeekRatingBinding;

public class ProgressSeekRatingActivity extends AppCompatActivity {

    private ActivityProgressSeekRatingBinding binding;
    private volatile boolean isRunning;  // 변수의 값이 모든 스레드에서 최신 상태로 유지되도록 보장하기 위해 사용

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_progress_seek_rating);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_progress_seek_rating);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setSupportActionBar(binding.materialToolbar7);
        getSupportActionBar().setTitle("Progress, Seek, Rating");
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        binding.container1.setVisibility(View.INVISIBLE);
        binding.container2.setVisibility(View.VISIBLE);

        binding.btnCalcStart.setOnClickListener(v -> {
            // 방법 1: 계산시작 버튼을 클릭하면, 아래 과정을 실행한다.
            //        container1을 보이게하고, container2를 감추고...
            //        container1의 progressBar가 보여야 하겠지만,
            //        아래 과정이 끝나야 UI 변경이 반영되는 문제가 생긴다.
            /*
            int i = 1;
            int sum = 0;

            binding.container1.setVisibility(View.VISIBLE);
            binding.container2.setVisibility(View.INVISIBLE);
            binding.progressBar.setProgress(0);
            for( ; i <= 10000; ++i) {
                sum += i;
                binding.progressBar.setProgress(i / 100);
                for(long j = 1; j <= 1000000; ++j) {  */ /* delay *//* }
                if(binding.progressBar.getProgress() == 100) {
                    break;
                }
            }
            binding.tvResult.setText(String.valueOf(sum));

            binding.container1.setVisibility(View.INVISIBLE);
            binding.container2.setVisibility(View.VISIBLE);
            */

            // 계산 과정을 Thread로 분리한다.
            Handler handler = new Handler(Looper.getMainLooper());
            new Thread(() -> {
                int sum = 0;
                // UI 업데이트는 Handler를 통해 UI 스레드에서 실행
                handler.post(() -> {
                    binding.container1.setVisibility(View.VISIBLE);
                    binding.container2.setVisibility(View.INVISIBLE);
                    binding.progressBar.setProgress(0);
                });

                /*
                for (int i = 1; i <= 10000; ++i) {
                    sum += i;
                    // 진행 과정을 UI에 전달
                    int progress = i;
                    handler.post(() -> binding.progressBar.setProgress(progress / 100));

                    try {
                        Thread.sleep(1); // 진행이 보이도록 delay
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    ;
                }
                */

                int i = 1;
                isRunning = true;
                while(isRunning) {
                    sum += i++;
                    int progress = i;
                    handler.post(() -> binding.progressBar.setProgress( progress / 100));
                    try {
                        Thread.sleep(1); // 진행이 보이도록 delay
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(i > 10000) break;
                }
                // 계산 완료 후 결과 표시
                int result = sum;
                handler.post(() -> {
                    binding.tvResult.setText(String.valueOf(result));
                    // 계산 완료 후 container 다시 원래대로
                    binding.container1.setVisibility(View.INVISIBLE);
                    binding.container2.setVisibility(View.VISIBLE);
                });
            }).start(); // Work 스레드 실행
        }); // end of setOnClickListener

        binding.btnCalcReStart.setOnClickListener(v -> {
            isRunning = false;
        });

        binding.btnCalcStart2.setOnClickListener(v -> {
            // 계산 과정을 Thread로 분리한다.
            Handler handler = new Handler(Looper.getMainLooper());
            new Thread(() -> {
                int sum = 0;
                // UI 업데이트는 Handler를 통해 UI 스레드에서 실행
                handler.post(() -> {
                    binding.container3.setVisibility(View.VISIBLE);
                    binding.container4.setVisibility(View.INVISIBLE);
                    binding.progressBar2.setProgress(0);
                });

                int i = 1;
                isRunning = true;

                while(isRunning) {
                    sum += i++;
                    int progress = i;
                    handler.post(() -> binding.progressBar2.setProgress( progress / 100));
                    try {
                        Thread.sleep(1); // 진행이 보이도록 delay
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(i > 10000) break;
                }
                // 계산 완료 후 결과 표시
                int result = sum;
                handler.post(() -> {
                    binding.tvResult2.setText(String.valueOf(result));
                    // 계산 완료 후 container 다시 원래대로
                    binding.container3.setVisibility(View.INVISIBLE);
                    binding.container4.setVisibility(View.VISIBLE);
                });
            }).start(); // Work 스레드 실행
        }); // end of setOnClickListener

        binding.btnCalcReStart2.setOnClickListener(v -> {
            isRunning = false;
        });

        // SeekBar는 Touch를 통해서 값을 변경할 수 있는 ProgressBar로 생각할 수 있다.
        binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Toast.makeText(getApplicationContext(), String.valueOf(progress), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "시작", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "끝", Toast.LENGTH_SHORT).show();
            }
        });

        // SeekBar/discrete는 이산형 SeekBar
        binding.seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Toast.makeText(getApplicationContext(), String.valueOf(progress), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "시작", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "끝", Toast.LENGTH_SHORT).show();
            }
        });

        binding.ratingBar.setOnClickListener(v -> {
            Toast.makeText(getApplicationContext(), "클릭(Rating)" + String.valueOf(binding.ratingBar.getRating()), Toast.LENGTH_SHORT).show();
        });

        binding.ratingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            Toast.makeText(getApplicationContext(), String.valueOf(rating), Toast.LENGTH_SHORT).show();
        });

        binding.btnRatingDecrease.setOnClickListener(v -> {
            if(binding.ratingBar.getRating() > 0) {
                binding.ratingBar.setRating(binding.ratingBar.getRating() - 0.5f);  // rating값은 float 타입이기 때문에 상수값을 더할 때 상수를 'f'를 붙여 float타입으로 변경 필요
            }
        });

        binding.btnRatingIncrease.setOnClickListener(v -> {
            if(binding.ratingBar.getRating() < binding.ratingBar.getNumStars()) {
                binding.ratingBar.setRating(binding.ratingBar.getRating() + 0.5f);
            }
        });
    } // end of onCreate
} // end of class